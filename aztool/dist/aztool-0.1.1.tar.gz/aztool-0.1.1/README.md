# aztool

A Python package to greet and fetch Wi-Fi (hotspot) details.

## Installation

```bash
pip install aztool
