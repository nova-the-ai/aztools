# aztool/__init__.py
from .core import greet, get_wifi_details

__version__ = "0.1.1"
__all__ = ["greet", "get_wifi_details"]
